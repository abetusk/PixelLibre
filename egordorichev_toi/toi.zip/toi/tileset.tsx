<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="tileset" tilewidth="8" tileheight="8" tilecount="768" columns="24">
 <image source="tileset.png" width="192" height="176"/>
</tileset>
