===================== Credits =====================
This graphic bundle is inspired by the video game 
"Flappy Bird" that was developed by Dong Nguyen.

Sprites in the pack were created by Megacrash.

Color palette: Endesga64.

Program: Aseprite
	 Tilesetter
==================================================

============ This package contain: ===============
14 player colors variations/2 player style
10 backgrounds variations
40 pipes variations
40 tilesets variations
==================================================

Anyone can use it in their project (commercial or non-commercial).
Lic. Creative Commons Zero v1.0 Universal

Thanks <3
				     Version 1.6