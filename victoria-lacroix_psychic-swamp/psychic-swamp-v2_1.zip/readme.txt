it's just a tileset dude. 
8x8 pixels, load it up in your tile editor of choice.
i dunno what you want me to write. 
there's no real layout or logic to where tiles are put.
it's kinda hard to make out what's what as a tileset.
but when it's split up into a grid it's a bit more obvious.

thanks for downloading also, i guess? 

- victoria